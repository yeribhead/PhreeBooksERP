<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: install
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /soap/language/pt_br/language.php

define('SOAP_NO_USER_PW','O nome de usuário e senha submetidos não foram encontrados no string XML.');
define('SOAP_USER_NOT_FOUND','O nome de usuário submetido não é válido.');
define('SOAP_PASSWORD_NOT_FOUND','A senha submetida não é válida.');
define('SOAP_UNEXPECTED_ERROR','O servidor retornou um código de erro inesperado.');
define('SOAP_XML_SUBMITTED_SO','Ordem de Venda submetida via XML');
define('SOAP_ACCOUNT_PROBLEM','Não foi possível encontrar um endereço principal para um cliente existente. Problema grave com a base de dados PhreeBooks.');
define('SOAP_MISSING_FIELDS','Ordem # %s não apresenta os seguintes campos: %s');
define('AUDIT_LOG_SOAP_10_ADDED','SOAP Ordens Venda - Inserir');
define('AUDIT_LOG_SOAP_12_ADDED','SOAP Vendas/Faturas - Inserir');
define('SOAP_10_SUCCESS','Ordem Venda %s foi baixada com sucesso.');
define('SOAP_12_SUCCESS','Fatura Venda %s foi baixada com sucesso.');

?>
