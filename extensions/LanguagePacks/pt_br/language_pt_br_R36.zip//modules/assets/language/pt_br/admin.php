<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/admin.php

define('TEXT_EDIT_FIELD','Editar Campo Ativo');
define('TEXT_NEW_FIELD','Novo Campo Ativo');
define('TEXT_EDIT_TAB','Editar Aba Ativo');
define('TEXT_NEW_USED','Novo/Usado');
define('TEXT_NEW_TAB','Nova Aba Ativo');
define('BOX_ASSETS_ADMIN','Ativos Módulo Gerenciamento ');
define('MODULE_ASSETS_TITLE','Ativos Módulo');
define('MODULE_ASSETS_DESCRIPTION','O módulo de ativos mantém um registro das propriedades da empresa. O módulo permite a criação de abas adicionais e campos para customização de acordo com a necessidade do usuário.');

?>
