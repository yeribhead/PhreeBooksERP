<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/menu.php

define('BOX_ASSET_MODULE','Ativos Gerenciamento');
define('MENU_HEADING_ASSETS','Ativos');

?>
