<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/language.php

define('TEXT_RETIRE_DATE','Data Baixa');
define('TEXT_LAND','Terra');
define('TEXT_IMAGE','Imagem');
define('TEXT_FURNITURE','Móveis');
define('TEXT_EQUIP','Máquinas e Equipamentos');
define('TEXT_DETAIL_DESCRIPTION','Descrição Detalhada');
define('TEXT_CONDITION','Condição');
define('TEXT_DESCRIPTION_SHORT','Descrição Curta');
define('TEXT_COMPUTER','Computador');
define('TEXT_BUILDING','Construção');
define('TEXT_ASSETS','ativos');
define('TEXT_ASSET_ID','ID Ativo');
define('TEXT_ACQ_DATE','Data Aquisição');
define('ASSETS_MSG_DELETE_ASSET','Tem certeza de que quer excluir este ativo?');
define('ASSETS_MSG_RENAME_INTRO','Entre a nova ID Ativo para este ativo.');
define('ASSETS_ENTRY_IMAGE_PATH','Imagem Caminho Relativo');
define('ASSETS_MSG_COPY_INTRO','Entre a nova ID Ativo para o novo ativo.');
define('ASSETS_PURCHASE_CONDITION','Condição Compra');
define('ASSETS_DATE_LAST_JOURNAL_DATE','Data Baixa Ativo');
define('ASSETS_DATE_LAST_UPDATE','Data Última Manutenção');
define('ASSETS_DATE_ACCOUNT_CREATION','Data Aquisição Ativo');
define('ASSETS_ENTRY_ASSETS_SERIALIZE','Marca/Modelo/Nº Série');
define('ASSETS_ENTRY_ACCT_COS','CG Conta Manutenção');
define('ASSETS_ENTRY_ACCT_INV','CG Conta Depreciação');
define('ASSETS_ENTRY_ACCT_SALES','CG Conta Ativo Patrimonial');
define('ASSETS_ENTRY_FULL_PRICE','Custo Original');
define('ASSETS_ENTRY_ASSETS_TYPE','Tipo Ativo');
define('ASSETS_ENTRY_ASSET_TYPE','Entre o Tipo de Ativo');
define('ASSETS_ENTER_ASSET_ID','Criar um Novo Ativo');
define('ASSETS_HEADING_NEW_ITEM','Novo Ativo');
define('TEXT_USED','Usado');
define('TEXT_VEHICLE','Veículo');
define('TEXT_TABS','Abas');
define('TEXT_SOFTWARE','Software');

?>
