<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: rma
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/pt_br/admin.php

define('MODULE_RMA_TITLE','Módulo ARM');
define('MODULE_RMA_DESCRIPTION','O módulo Autorização Retorno Mercadoria (ARM) gerencia retorno de mercadoria de clientes.');
define('NEXT_RMA_NUM_DESC','Próximo Número ARM:');

?>
