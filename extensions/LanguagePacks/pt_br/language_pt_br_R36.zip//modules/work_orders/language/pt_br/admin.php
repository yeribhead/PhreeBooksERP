<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/admin.php

define('MODULE_WORK_ORDERS_TITLE','Módulo Ordem Serviço');
define('MODULE_WORK_ORDERS_DESCRIPTION','The Work Order module provides a complete inventory production control system. This module interacts with the Inventory module to control the build process and help manage inventory.');
define('TEXT_WORK_ORDER_FORMS','Ordem Serviço');
define('NEXT_WO_NUM_DESC','Número Próxima Ordem Serviço');

?>
