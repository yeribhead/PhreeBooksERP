<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/menu.php

define('MENU_HEADING_WORK_ORDERS','Ordens Serviço');
define('BOX_WORK_ORDERS_MODULE','Ordem Serviço Gerenciador');
define('BOX_WORK_ORDERS_BUILDER','Ordem Serviço Construtor');
define('BOX_WORK_ORDERS_MODULE_TASK','Ordem Serviço Tarefas');

?>
