<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: audit
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/admin.php

define('TEXT_AUDIT_DEBIT_NUMBER','Seu número ou ID no seu contador');
define('MODULE_AUDIT_CONFIG_INFO','Por favor defina seu valor de configuração');
define('TEXT_AUDIT_SETTINGS','Propriedades Auditoria');
define('BOX_AUDIT_ADMIN','Configuração Auditoria.');
define('MODULE_AUDIT_TITLE','Auditoria');
define('MODULE_AUDIT_DESCRIPTION','Este módulo criará uma página na qual você poderá selecionar o período que você quer exportar como um arquivo .xaf para seu contador ou autoridade fiscal.');

?>
