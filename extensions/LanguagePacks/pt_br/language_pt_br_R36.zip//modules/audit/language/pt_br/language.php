<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: audit
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/language.php

define('TEXT_EXCLUDE','excluir');
define('GL_ERROR_BALANCE','As contas CG não batem');
define('TEXT_ALL_OR_ACTIVE','Você quer exportar todas ou todas excluindo as ordens, cotações e itens aguardando faturamento');
define('TEXT_BALANCE_SHEET','Balancete');
define('TEXT_INCOME_STATEMENT','Demonstrativo Resultados');
define('HEADING_MODULE_AUDIT','exportar arquivo de auditoria');

?>
