<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: audit
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/menu.php

define('BOX_AUDIT_MODULE','Auditar / exportar xaf');

?>
