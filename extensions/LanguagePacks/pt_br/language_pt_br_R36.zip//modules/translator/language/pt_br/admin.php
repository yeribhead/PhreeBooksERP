<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: translator
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/pt_br/admin.php

define('MODULE_TRANSLATOR_TITLE','Módulo Tradução');
define('MODULE_TRANSLATOR_DESCRIPTION','O móudlo de Tradução apresenta uma interface conveniente para traduzir arquivos de idioma. Este módulo gerencia versões de atualização bem como um suporte pleno para uma tradução inicial.');

?>
