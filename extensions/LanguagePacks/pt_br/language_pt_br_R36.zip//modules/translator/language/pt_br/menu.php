<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: translator
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/pt_br/menu.php

define('MENU_HEADING_TRANSLATOR','Ferramenta Assistente Tradução');
define('BOX_TRANSLATOR_MODULE','Assistente Tradução');

?>
