<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-todays_s_quotes
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_s_quotes/language/pt_br/language.php

define('CP_TODAYS_S_QUOTES_TITLE','Cotações de Venda de Hoje');
define('CP_TODAYS_S_QUOTES_DESCRIPTION','Lista as cotações de vendas de hoje. Conexão para rever as cotações.');

?>
