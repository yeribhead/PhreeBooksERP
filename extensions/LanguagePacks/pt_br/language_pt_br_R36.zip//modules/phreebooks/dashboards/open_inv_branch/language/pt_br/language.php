<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-open_inv_branch
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv_branch/language/pt_br/language.php

define('CP_OPEN_INV_BRANCH_TITLE','Faturas em Aberto por Filial');
define('CP_OPEN_INV_BRANCH_DESCRIPTION',' Lista vendas/faturas pela filial padrão do usuário. Conexão para rever a venda/fatura.');

?>
