<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-todays_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/pt_br/language.php

define('CP_TODAYS_ORDERS_TITLE','Ordens de Venda de Hoje');
define('CP_TODAYS_ORDERS_DESCRIPTION','Lista as ordens de venda de hoje. Conexões para rever as ordens de venda.');

?>
