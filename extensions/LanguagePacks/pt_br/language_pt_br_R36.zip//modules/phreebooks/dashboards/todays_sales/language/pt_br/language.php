<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-todays_sales
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/pt_br/language.php

define('CP_TODAYS_SALES_TITLE','Vendas de Hoje');
define('CP_TODAYS_SALES_DESCRIPTION','Lista as faturas de venda de hoje. Conexão para rever a fatura.');

?>
