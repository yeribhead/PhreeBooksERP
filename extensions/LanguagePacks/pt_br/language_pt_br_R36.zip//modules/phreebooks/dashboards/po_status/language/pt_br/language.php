<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-po_status
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/pt_br/language.php

define('CP_PO_STATUS_TITLE','Compras Ordens em Aberto');
define('CP_PO_STATUS_DESCRIPTION',' Lista ordens de compra com situação atual em aberto. Conexão para rever as ordens de compra.');
define('CP_PO_STATUS_SORT_ORDER','Ordenar por Data Entrada');
define('CP_PO_STATUS_HIDE_FUTURE','Restringir a Hoje e Anteriores');

?>
