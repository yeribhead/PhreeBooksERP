<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-open_inv
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/pt_br/language.php

define('CP_OPEN_INV_TITLE','Faturas em Aberto');
define('CP_OPEN_INV_DESCRIPTION','Lista vendas/faturas em aberto. Conexão para reer venda/fatura.');

?>
