<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks-so_status
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/pt_br/language.php

define('CP_SO_STATUS_TITLE','Vendas Ordens em Aberto');
define('CP_SO_STATUS_DESCRIPTION','Lista as ordens de venda com situação atual em aberto. Conexão para rever as ordens de compra.');
define('CP_SO_STATUS_SORT_ORDER','Ordenar por Data Entrada');
define('CP_SO_STATUS_HIDE_FUTURE','Restringir para Hoje e Anteriores');

?>
