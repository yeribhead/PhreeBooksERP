<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/acct_recon.php

define('RW_RECON_TPC','Total Pagamentos Finalizadas');
define('RW_RECON_TDC','Total Depósitos Finalizadas');
define('RW_RECON_PCLEARED','Pagamentos Finalizadas');
define('RW_RECON_DCLEARED','Depósitos Finalizadas');
define('RW_RECON_CLEARED','Transações Finalizadas');
define('RW_RECON_TBD','Coluna Espaço Reservado');
define('RW_RECON_DIFF','Diferenças Não Consciliadas');
define('RW_RECON_TOP','Total Encargos Futuros');
define('RW_RECON_LOP','Menos Encargos Futuros');
define('RW_RECON_DIT','Total Depósitos em Trânsito');
define('RW_RECON_ADD_BACK','Inserir Depósitos de Retorno em Trânsito');
define('RW_RECON_EB','Saldo Final CG');
define('RW_RECON_CD','Caixa Saídas');
define('RW_RECON_NCLEARED','Líquido Finalizado');
define('RW_RECON_CR','Caixa Entradas');
define('RW_RECON_BB','Saldo Inicial CG');

?>
