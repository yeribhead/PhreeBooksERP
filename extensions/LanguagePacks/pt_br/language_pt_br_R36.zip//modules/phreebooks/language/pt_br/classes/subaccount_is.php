<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/subaccount_is.php

define('RW_FIN_NET_INCOME','Net Income');
define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');
define('RW_RECORD_ID','Coluna Espaço Reservado');

?>
