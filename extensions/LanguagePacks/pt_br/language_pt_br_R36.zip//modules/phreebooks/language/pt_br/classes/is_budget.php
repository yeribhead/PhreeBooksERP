<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/is_budget.php

define('IS_BUDGET_CUR_BUDGET','Orçamento Corrente');
define('IS_BUDGET_LY_CUR','Último Ano Corrente');
define('IS_BUDGET_LAST_YTD','Último Ano até a Data');
define('IS_BUDGET_YTD','Ano até a Data');
define('IS_BUDGET_CUR_MONTH','Mês Corrente');
define('RW_FIN_NET_INCOME','Receita Líquida');
define('IS_BUDGET_ACCOUNT','Conta');
define('RW_FIN_EXPENSES','Despesas');
define('RW_FIN_GROSS_PROFIT','Lucro Bruto');
define('IS_BUDGET_YTD_BUDGET','Orçamento Ano até a Data');
define('RW_FIN_COST_OF_SALES','Custo Vendas');
define('RW_FIN_REVENUES','Receitas');

?>
