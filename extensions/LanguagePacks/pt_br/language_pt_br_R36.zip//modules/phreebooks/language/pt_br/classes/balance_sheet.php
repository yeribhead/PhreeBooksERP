<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/balance_sheet.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Passivos & Capital');
define('RW_FIN_TOTAL_CAPITAL','Total Capital');
define('RW_FIN_NET_INCOME','Receita Líquida');
define('RW_FIN_TOTAL_LIABILITIES','Total Passivos');
define('RW_FIN_CAPITAL','Capital');
define('RW_FIN_TOTAL_LT_LIABILITIES','Total Passivo Longo Prazo');
define('RW_FIN_LONG_TERM_LIABILITIES','Passivo Longo Prazo');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Total Passivos Correntes');
define('RW_FIN_CUR_LIABILITIES','Passivos Correntes');
define('RW_FIN_TOTAL_PROP_EQUIP','Total Imóveis e Equipamentos');
define('RW_FIN_TOTAL_ASSETS','Total Ativos');
define('RW_FIN_PROP_EQUIP','Imóveis e Equipamentos');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Total Ativos Correntes');
define('RW_FIN_CURRENT_ASSETS','Ativos Correntes');

?>
