<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/income_statement.php

define('RW_FIN_NET_INCOME','Receita Líquida');
define('RW_FIN_EXPENSES','Despesas');
define('RW_FIN_COST_OF_SALES','Custo Vendas');
define('RW_FIN_GROSS_PROFIT','Lucro Bruto');
define('RW_FIN_REVENUES','Receitas');

?>
