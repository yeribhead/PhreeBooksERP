<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/balance_sheet_au.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Liabilities & Capital');
define('RW_FIN_TOTAL_CAPITAL','Total Equity');
define('RW_FIN_NET_INCOME','Net Income');
define('RW_FIN_CAPITAL','Equity');
define('RW_FIN_TOTAL_LIABILITIES','Total Liabilities');
define('RW_FIN_NET_ASSETS','Net Assets');
define('RW_FIN_TOTAL_LT_LIABILITIES','Total Non-Current Liabilities');
define('RW_FIN_LONG_TERM_LIABILITIES','Non-Current Liabilities');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Total Current Liabilities');
define('RW_FIN_CUR_LIABILITIES','Current Liabilities');
define('RW_FIN_TOTAL_PROP_EQUIP','Total Non-Current Assets');
define('RW_FIN_TOTAL_ASSETS','Total Assets');
define('RW_FIN_PROP_EQUIP','Non-Current Assets');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Total Current Assets');
define('RW_FIN_CURRENT_ASSETS','Current Assets');

?>
