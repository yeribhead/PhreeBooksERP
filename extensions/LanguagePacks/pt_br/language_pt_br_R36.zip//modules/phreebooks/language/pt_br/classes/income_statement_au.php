<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/income_statement_au.php

define('RW_FIN_NET_INCOME','Net Income');
define('RW_FIN_EXPENSES','Expenses');
define('RW_FIN_COST_OF_SALES','Cost of Sales');
define('RW_FIN_GROSS_PROFIT','Gross Profit');
define('RW_FIN_REVENUES','Revenues');

?>
