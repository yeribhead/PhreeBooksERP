<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: xml_builder
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/xml_builder/language/pt_br/language.php

define('XML_BUILDER_PAGE_TITLE','Módulo Construtor XML');

?>
