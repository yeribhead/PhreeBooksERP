<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: xml_builder
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/xml_builder/language/pt_br/menu.php

define('BOX_XML_BUILDER_TITLE','Construtor XML');

?>
