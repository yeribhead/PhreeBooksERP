<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: xml_builder
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/xml_builder/language/pt_br/admin.php

define('MODULE_XML_BUILDER_TITLE','Construtor XML');
define('MODULE_XML_BUILDER_DESCRIPTION','Este módulo constrói os arquivos de informação XML.');

?>
