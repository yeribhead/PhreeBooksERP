<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: bulk_inv
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/bulk_inv/language/pt_br/admin.php

define('MODULE_BULK_INV_TITLE','Ferramenta de Inventário em Lote');
define('MODULE_BULK_INV_DESCRIPTION','Esta ferramenta ajuda a entrar informação na base de dados de forma mais rápida que o Gerenciador de Inventário.');

?>
