<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: inventory
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/pt_br/menu.php

define('BOX_SALES_PRICE_SHEETS','Tabelas Preço Clientes');
define('BOX_PURCHASE_PRICE_SHEETS','Tabelas Preço Fornecedores');
define('BOX_PRICE_SHEET_MANAGER','Tabelas Preço');
define('ORD_TEXT_16_WINDOW_TITLE','Ajustes');
define('ORD_TEXT_14_WINDOW_TITLE','Montagens');
define('BOX_INV_TRANSFER','Transferir Estoque');
define('BOX_INV_NEW','Novo Estoque');
define('BOX_INV_MAINTAIN','Estoque');
define('MENU_HEADING_INVENTORY','Estoque');

?>
