<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: phreepos
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/pt_br/menu.php

define('MENU_HEADING_PHREEPOS','Ponto de Venda');
define('BOX_PHREEPOS','Ponto de Venda');
define('BOX_POS_MGR','Gerenciador PDV');
define('BOX_POS_CLOSING','Fechando PDV');
define('BOX_CUSTOMER_DEPOSITS','Depósitos Clientes');
define('BOX_VENDOR_DEPOSITS','Depósitos Fornecedores');

?>
