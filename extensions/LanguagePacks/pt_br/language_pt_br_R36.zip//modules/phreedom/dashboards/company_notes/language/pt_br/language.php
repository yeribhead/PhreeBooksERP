<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-company_notes
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_notes/language/pt_br/language.php

define('CP_COMPANY_NOTES_TITLE','Empresa Anotações');
define('CP_COMPANY_NOTES_DESCRIPTION','Permite postar anotações e lembretes visíveis para toda a empresa.');

?>
