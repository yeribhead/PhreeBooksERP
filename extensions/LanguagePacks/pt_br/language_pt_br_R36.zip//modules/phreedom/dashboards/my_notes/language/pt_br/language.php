<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-my_notes
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/pt_br/language.php

define('CP_MY_NOTES_TITLE','Minhas Anotações');
define('CP_MY_NOTES_DESCRIPTION','Permite postar anotações e lembretes');

?>
