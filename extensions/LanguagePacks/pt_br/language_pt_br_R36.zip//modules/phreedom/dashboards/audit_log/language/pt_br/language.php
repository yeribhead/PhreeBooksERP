<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-audit_log
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/audit_log/language/pt_br/language.php

define('CP_AUDIT_LOG_TITLE','Registro Auditoria');
define('CP_AUDIT_LOG_DESCRIPTION','Lista o registro de auditoria para um dia específico. O módulo tem um controle para setar o dia a ser visualizado.');
define('CP_AUDIT_LOG_DISPLAY','Mostrar entradas');
define('CP_AUDIT_LOG_DISPLAY2','dia(s) atrás (Hoje=0)');

?>
