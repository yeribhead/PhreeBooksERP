<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: phreedom-to_do
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/pt_br/language.php

define('CP_TO_DO_TITLE','Tarefas a Realizar');
define('CP_TO_DO_DESCRIPTION','Cria uma lista de tarefas e atividades a realizar');

?>
