<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-company_links
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/pt_br/language.php

define('CP_COMPANY_LINKS_TITLE','Empresa Conexões');
define('CP_COMPANY_LINKS_DESCRIPTION','Lista URLs para todos os usuários como conexões da empresa.');

?>
