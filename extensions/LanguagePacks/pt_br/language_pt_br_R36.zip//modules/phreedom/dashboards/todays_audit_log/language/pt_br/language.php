<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: phreedom-todays_audit_log
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/todays_audit_log/language/pt_br/language.php

define('CP_TODAYS_AUDIT_LOG_TITLE','Registro Auditoria de Hoje');
define('CP_TODAYS_AUDIT_LOG_DESCRIPTION','Lista os registros de auditoria de hoje');

?>
