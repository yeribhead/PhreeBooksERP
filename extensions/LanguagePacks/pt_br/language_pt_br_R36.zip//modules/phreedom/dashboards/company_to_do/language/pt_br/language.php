<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-company_to_do
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_to_do/language/pt_br/language.php

define('CP_COMPANY_TO_DO_TITLE','Empresa Tarefas a Realizar');
define('CP_COMPANY_TO_DO_DESCRIPTION','Cria uma lista de atividades e tarefas a realizar visíveis para toda a empresa.');

?>
