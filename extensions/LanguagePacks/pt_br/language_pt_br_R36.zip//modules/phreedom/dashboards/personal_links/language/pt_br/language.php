<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: phreedom-personal_links
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/pt_br/language.php

define('CP_PERSONAL_LINKS_TITLE','Minhas Conexões');
define('CP_PERSONAL_LINKS_DESCRIPTION','Lista URLs para uso pessoal como acesso rápido');

?>
