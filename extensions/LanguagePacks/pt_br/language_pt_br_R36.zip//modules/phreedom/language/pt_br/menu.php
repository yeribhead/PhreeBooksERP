<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: phreedom
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/pt_br/menu.php

define('BOX_HEADING_CONFIGURATION','Administração Módulos');
define('BOX_COMPANY_MANAGER','Empresa');
define('BOX_HEADING_ADMIN_TOOLS','Ferramentas Adiministrativas');
define('BOX_IMPORT_EXPORT','Importar/Exportar');
define('BOX_HEADING_ENCRYPTION','Criptografia Dados');
define('BOX_HEADING_BACKUP','Backup Empresa');
define('BOX_HEADING_USERS','Usuários');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Funcionários');
define('BOX_CONTACTS_NEW_EMPLOYEE','Novo Funcionário');
define('MENU_HEADING_EMPLOYEES','Funcionários');
define('TEXT_STATISTICS','Estatísticas');
define('MENU_HEADING_EMAIL','Email Preferências');
define('MENU_HEADING_CONFIG','Configuração');
define('MENU_HEADING_MY_COMPANY','Minha Empresa');
define('MENU_HEADING_MODULES','Módulos');
define('BOX_HEADING_ROLES','Direitos');
define('HEADING_TITLE_USERS','Usuários');
define('BOX_HEADING_PROFILE','Meu Perfil');
define('MENU_HEADING_TOOLS','Ferramentas');
define('MENU_HEADING_COMPANY','Empresa');
define('TEXT_LOGOUT','Log Out');
define('TEXT_HOME','Home');
define('CHARSET','windows-1252');
define('HTML_PARAMS','lang=\"pt-BR\" xml:lang=\"pt-BR\"');
define('TEXT_PHREEDOM_INFO','EDS Brasil Business Solutions');
define('TITLE','EDS Brasil ERP');
define('LANGUAGE','Portugues (BR)');
define('BOX_GENERAL_ADMIN','Configurações Gerais');
define('BOX_HEADING_DEBUG_DL','Baixar Arquivo Debug');

?>
