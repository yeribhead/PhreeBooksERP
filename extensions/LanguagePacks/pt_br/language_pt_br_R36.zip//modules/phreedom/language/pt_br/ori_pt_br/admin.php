<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: phreedom
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/pt_br/ori_pt_br/admin.php

define('HTML_PARAMS','lang=\"pt-BR\" xml:lang=\"pt-BR\"');
define('TEXT_PHREEDOM_INFO','EDS Brasil Business Solutions');
define('TITLE','EDS Brasil ERP');
define('LANGUAGE','Portugues (BR)');
define('CHARSET','utf-8');

?>
