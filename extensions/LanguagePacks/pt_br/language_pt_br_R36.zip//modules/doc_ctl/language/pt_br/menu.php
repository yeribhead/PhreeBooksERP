<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/menu.php

define('MENU_HEADING_QUALITY','Qualidade');
define('BOX_DOC_CTL_MODULE','Controle Documento');

?>
