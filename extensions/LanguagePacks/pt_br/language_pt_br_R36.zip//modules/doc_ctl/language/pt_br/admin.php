<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/admin.php

define('MODULE_DOC_CTL_TITLE','Módulo Controle Documentos');
define('MODULE_DOC_CTL_DESCRIPTION','O módulo de controle de documentos fornece um sistema de gerenciamento de documentos para controlar vários tipos de documentos. O módulo inclui funções para baixar/subir documentos, pesquisar para alterações, segurança e gerenciamento estruturado de pastas.');

?>
