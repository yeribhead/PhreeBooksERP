<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/language.php

define('TEXT_BOOKMARK_DOC','Marcar Documento');
define('TEXT_BOOKMARKED','Marcado');
define('TEXT_CANCEL_CHECKOUT','Cancelar Flag Conferido');
define('TEXT_CHECKED_OUT','Conferido');
define('TEXT_CHECKOUT_DOC','Conferir Documento');
define('TEXT_CREATE_DATE','Data Criação');
define('TEXT_DETAILS','Detalhes');
define('TEXT_DOCUMENT','Documento:');
define('TEXT_DOCUMENT_TITLE','Conteúdo de:');
define('TEXT_DOCUMENTS','Lista Documentos');
define('TEXT_DOWNLOAD_DOCUMENT','Baixar Documento');
define('TEXT_FILENAME','Nome Arquivo');
define('TEXT_IMG_NOT_AVAILABLE','Imagem Não Disponível');
define('TEXT_LAST_UPDATE','Última Atualização');
define('TEXT_LAST_VIEW','Última Visualização');
define('TEXT_LOCK_DOC','Travar Documento');
define('TEXT_LOCKED','Travado');
define('TEXT_MY_BOOKMARKS','Minhas Marcações');
define('TEXT_MY_CHECKED_OUT','Arquivos Verificados');
define('TEXT_NEW_FOLDER','Nova Pasta');
define('TEXT_NEW_DOCUMENT','Novo Documento');
define('TEXT_NO_BOOKMARKS','Não foram feitas marcações');
define('TEXT_NO_CHECKED_OUT','Não foram encontrados arquivos verificados');
define('TEXT_NO_DOCUMENTS','Não forma encontrados documentos');
define('TEXT_OWNER','Proprretário');
define('TEXT_PATH','Caminho');
define('TEXT_RECENTLY_ADDED','Documentos Recentes');
define('TEXT_REMOVE_BOOKMARK','Remover Marcação');
define('TEXT_REVISION','Revisão');
define('TEXT_THUMBNAIL','Miniatura');
define('TEXT_UNLOCK_DOC','Destravar Documentos');
define('TEXT_UPLOAD_FILE','Subir Revisão');
define('DOC_CTL_EMPTY_FOLDER','A pasta não contém nenhum documento.');
define('DOC_CTL_FILE_WRITE_ERROR','Houve um erro ao gravar o arquivo. Verifique as permissões da pasta (%s)e tente novamente.');
define('DOC_CTL_ITEMS','Pastas e Documentos');
define('DOC_CTL_DELETE_DOCUMENT','Tem certeza de que quer remover este documento?');
define('DOC_CTL_DELETE_DIRECTORY','Tem certeza de que quer remover esta pasta?');
define('DOC_CTL_JS_DEL_BOOKMARK','Tem certeza de que quer remover esta marcação?');
define('DOC_CTL_JS_DIR_DELETED_ERROR','A pasta não está vazia, não pode ser removida!');

?>
