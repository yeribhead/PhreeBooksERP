<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/menu.php

define('BOX_SKU_PRICER_TITLE','SKU Preços');

?>
