<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/language.php

define('SKU_PRICER_PAGE_TITLE','SKU Importação Preços');
define('SKU_PRICER_SELECT','Por favor selecione o arquivo . csv para importação');
define('SKU_PRICER_DIRECTIONS','Depois de selecionar o arquivo tecle o botão Salvar para executar o  script.<br />O formato do arquivo (com cabeçalho):<br />sku,custo,preço,código upc<br>SKU_NUM,2.00, 4.00, upc<br />Números com valor real com ponto como separador decimal, sem símbolos ou outros caracteres.');

?>
