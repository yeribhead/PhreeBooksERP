<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:46
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/admin.php

define('MODULE_SKU_PRICER_TITLE','SKU Preços');
define('MODULE_SKU_PRICER_DESCRIPTION','Este módulo vai atualizar o preço cheio de um SKU a partir de um arquivo csv.');

?>
