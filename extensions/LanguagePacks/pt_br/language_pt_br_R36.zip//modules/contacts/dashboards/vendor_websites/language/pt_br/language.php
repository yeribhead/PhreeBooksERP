<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: contacts-vendor_websites
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/contacts/dashboards/vendor_websites/language/pt_br/language.php

define('CP_VENDOR_WEBSITES_TITLE','Websites de Fornecedores');
define('CP_VENDOR_WEBSITES_DESCRIPTION','Lista URLs para todos os fornecedores.');
define('CP_VENDOR_WEBSITES_NO_RESULTS','Não foram encontrados resultados!');

?>
