<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: contacts-customer_websites
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/contacts/dashboards/customer_websites/language/pt_br/language.php

define('CP_CUSTOMER_WEBSITES_TITLE','Websites de Clientes');
define('CP_CUSTOMER_WEBSITES_DESCRIPTION','Lista URLs para todos os clientes.');
define('CP_CUSTOMER_WEBSITES_NO_RESULTS','Não foram encontrados resultados!');

?>
