<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: contacts
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/pt_br/menu.php

define('BOX_HR_DEPARTMENTS','Departamentos');
define('BOX_CONTACTS_NEW_CONTACT','Novo Contato');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Fornecedores');
define('BOX_CONTACTS_NEW_VENDOR','Novo Fornecedor');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Projetos');
define('BOX_CONTACTS_NEW_PROJECT','Novo Projeto');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Funcionários');
define('BOX_CONTACTS_NEW_EMPLOYEE','Novo Funcionário');
define('MENU_HEADING_EMPLOYEES','Funcionários');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Clientes');
define('BOX_CONTACTS_NEW_CUSTOMER','Novo Cliente');
define('BOX_CONTACTS_MAINTAIN_BRANCHES',' Filial');
define('BOX_CONTACTS_NEW_BRANCH','Nova Filial');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('MENU_HEADING_VENDORS','Fornecedores');
define('MENU_HEADING_CUSTOMERS','Clientes');
define('BOX_PROJECTS_PHASES','Fases Projeto');
define('BOX_PROJECTS_COSTS','Custos Projeto');

?>
