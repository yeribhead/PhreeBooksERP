<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/pt_br/menu.php

define('MENU_HEADING_PHREEPAY','Módulo Pagamento');

?>
