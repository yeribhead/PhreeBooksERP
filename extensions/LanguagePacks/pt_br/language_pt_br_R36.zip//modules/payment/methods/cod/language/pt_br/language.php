<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment-cod
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/pt_br/language.php

define('MODULE_PAYMENT_COD_TEXT_TITLE','Pagamento na Entrega');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Pagamento na Entrega');

?>
