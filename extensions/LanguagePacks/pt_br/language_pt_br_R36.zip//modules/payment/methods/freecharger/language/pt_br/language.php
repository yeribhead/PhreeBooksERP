<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment-freecharger
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/pt_br/language.php

define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Pagamento Livre');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Método de pagamento livre para uso com copras que não precisam de pagamento.');

?>
