<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment-moneyorder
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/pt_br/language.php

define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Ordem PAgamento/Cheque');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION','Pagamentos via cheque, ordem de pagamento e outras formas de pagamento direto.');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Número Referência');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Fazer Pagamentos para:');

?>
