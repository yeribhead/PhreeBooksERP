<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment-directdebit
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/pt_br/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Débito Direto');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Pagamentos com Débito Direto e TED');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Número Referência');

?>
