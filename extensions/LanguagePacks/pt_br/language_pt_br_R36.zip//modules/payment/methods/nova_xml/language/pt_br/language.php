<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: payment-nova_xml
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/nova_xml/language/pt_br/language.php

define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE','Elevon');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION','Aceitar pagamentos cartão de crédito via gateway de pagamentos Elevon');
define('MODULE_PAYMENT_NOVA_XML_TEXT_INTRODUCTION','Quando em modo de teste cartões retornam um código de sucesso mas não são processados.');
define('MODULE_PAYMENT_NOVA_XML_STATUS_DESC','Você quer aceitar pagamentos Elevon Network?');
define('MODULE_PAYMENT_NOVA_XML_MERCHANT_ID_DESC','ID Elevon Merchant utilizado pelo serviço Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_USER_ID_DESC','ID Usuário Elevon utilizado pelo serviço Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_PIN_DESC','PIN utilizado pelo serviço Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_TESTMODE_DESC','Modo de transação utilizado para processar ordens');
define('MODULE_PAYMENT_NOVA_XML_AUTHORIZATION_TYPE_DESC','Você quer que as transações de cartão de crédito submetidas sejam somente autorizadas ou autorizadas e capturadas?');

?>
