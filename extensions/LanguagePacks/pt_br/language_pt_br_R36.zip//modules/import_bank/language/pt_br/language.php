<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/language.php

define('MODULE_IMPORT_BANK_TITLE','Importar lançamentos bancários');
define('HEADING_MODULE_IMPORT_BANK','Importar lançamentos bancários');
define('GEN_BANK_IMPORT_MESSAGE','Seleciona o arquivo .csv para importar e tecle Importar <br> Se não existe a coluna conta bancária no seu .csv selecione uma conta bancária na caixa de seleção.');
define('TEXT_IMPORT','Importar');
define('SAMPLE_CSV','Exemplo de CSV');
define('TEXT_REQUIRED','OBRIGATÓRIO');
define('TEXT_BIMP_ERMSG1','proprietário conta bancária está vazio');
define('TEXT_BIMP_ERMSG2','existem duas ou mais contas CG com a descrição: ');
define('TEXT_BIMP_ERMSG3','a outra conta bancária está vazia');
define('TEXT_BIMP_ERMSG4','existem duas ou mais contas com a mesma conta bancária');
define('TEXT_BIMP_ERMSG5','não existem contas CG com a descrição:');
define('GENERAL_JOURNAL_7_DESC','Crédito');
define('TEXT_NEW_BANK','Encontrado um novo número de Banco. Você pode adicionar o  número de Banco = %s ao Contato = %s ');
define('TEXT_NEW_IBAN','Encontrado um novo número IBAN. Você pode adicionar o IBAN = %s ao Contato = %s ');

?>
