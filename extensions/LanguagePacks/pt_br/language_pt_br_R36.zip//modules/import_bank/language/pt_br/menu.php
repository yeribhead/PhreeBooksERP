<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/menu.php

define('BOX_IMPORT_BANK_MODULE','Importar lançamentos bancários');

?>
