<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/admin.php

define('MODULE_IMPORT_BANK_TITLE','Importar lançamentos bancários');
define('MODULE_IMPORT_BANK_DESCRIPTION','Com este módulo você pode importar lançamentos bancários. Esta lista será verificada contra as cobranças pendenes ou lançamentos anteriores com a mesma descrição.');
define('BOX_BANK_IMPORT_ADMIN','Propriedades Importação Bancos');
define('TEXT_BANK_IMPORT_SETTINGS','Propriedades Importação Bancos');
define('MODULE_BANK_IMPORT_CONFIG_INFO','Por favor defina  o valor de configuração');
define('BANK_IMPORT_QUESTION_POSTS','Para garantir que lançamentos sejam lançados pelo script como último recurso os lançamentos são armazenados como itens em dúvida.</B> Isto deve ser preenchido ou o sript não funcionará.</B>');
define('BANK_IMPORT_DEBIT_CREDIT','A descrição quando valores são creditados em sua conta <br> <B> isto é para o campo xml debit_credit</B>');
define('IMPORT_BANK_CONFIG_SAVED','config import-bank gravado');
define('TEXT_BANK_ACCOUNT','Conta bancária ou IBAN');
define('TEXT_ENTER_TRANSACTION','Entre novo modelo de transação');
define('TEXT_EDIT_TRANSACTION','Editar modelo de transação');
define('TEXT_KNOWN_TRANSACTION','Modelo de Transação');

?>
