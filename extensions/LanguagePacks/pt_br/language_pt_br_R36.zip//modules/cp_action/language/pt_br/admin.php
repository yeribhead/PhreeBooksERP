<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: cp_action
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/cp_action/language/pt_br/admin.php

define('MODULE_CP_ACTION_TITLE','Módulo AC/AP');
define('MODULE_CP_ACTION_DESCRIPTION','The Corrective Action/Preventativce action module is useed as part of an internal quality control system to record, track and monitor problems in the company organizational process.');
define('NEXT_CAPA_NUM_DESC',' Próximo Número Ação Corretiva/Preventiva');

?>
