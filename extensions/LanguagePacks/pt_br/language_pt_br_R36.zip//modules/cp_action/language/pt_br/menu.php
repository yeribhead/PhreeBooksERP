<?php
// +-----------------------------------------------------------------+
// Arquivo Tradução Idioma  Phreedom 
// Generated: 2013-10-22 05:28:45
// Module/Method: cp_action
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/cp_action/language/pt_br/menu.php

define('MENU_HEADING_QUALITY','Qualidade');
define('MENU_HEADING_CAPA','Ação Corretiva/Preventiva');
define('BOX_CAPA_MODULE','Ação C/P');

?>
